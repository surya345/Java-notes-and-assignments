package com.stackroute;

public class EventTicket {
    int eventId=101;
    String eventName ="Music-show";
    String purchaseDate = "2nd-April-2020";
    String eventTime = "4:00-pm";
    String address = "Bangalore";
    String eventDescription = "Live-Concert";

   protected void displayEventInfo()
   {
       System.out.println(eventId +" "+eventName+" " +purchaseDate+" "+eventTime+" "+ address+" " +eventDescription);
   }


}
