package com.stackroute;

public class GoldStagEventTicket extends GoldEventTicket {
    int id;
    String subCategory="GoldStag";

    public void setTicketNumber(int ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }
}
