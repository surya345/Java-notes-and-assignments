package com.stackroute;

public class GoldEventTicket extends EventTicket {
    String category="GoldEvent";
    int capacity=100;
    float price=400F;
    int ticketNumber;
    String seatNumber;

    protected void displayGoldEventInfo() {
        displayEventInfo();
        System.out.println(category +" "+ capacity + " "+ price +" "+ ticketNumber+" " + seatNumber );


    }
}
