package com.stackroute;

public class GoldCoupleEventTicket extends GoldEventTicket {
    int id;
    String subCategory ="GoldCouple";

    public void setTicketNumber(int ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }


}
