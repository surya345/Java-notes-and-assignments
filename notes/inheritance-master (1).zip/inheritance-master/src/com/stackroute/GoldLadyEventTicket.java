package com.stackroute;

public class GoldLadyEventTicket extends GoldEventTicket{
    int id;
    String subCategory="GoldLady";

    public void setTicketNumber(int ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }
}
