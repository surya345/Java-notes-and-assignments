package com.stackroute;

public class PlatinumEventTicket extends EventTicket{
    String category="PlatinumEvent";
    int capacity=50;
    float price=600F;
    int ticketNumber;
    String seatNumber;

    public void setTicketNumber(int ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    protected void displayPlatinumEventInfo() {
        displayEventInfo();
        System.out.println(category +" "+ capacity + " "+ price +" "+ ticketNumber+" " + seatNumber );


    }


}
