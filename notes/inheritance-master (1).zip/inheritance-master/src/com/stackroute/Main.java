package com.stackroute;

public class Main {
    public static void main(String[] args) {

        PlatinumEventTicket platinumEventTicket = new PlatinumEventTicket();
        platinumEventTicket.setTicketNumber(101);
        platinumEventTicket.setSeatNumber("G1");

        GoldCoupleEventTicket goldCoupleEventTicket = new GoldCoupleEventTicket();
        goldCoupleEventTicket.setTicketNumber(01);
        goldCoupleEventTicket.setSeatNumber("A1");

        GoldLadyEventTicket goldLadyEventTicket = new GoldLadyEventTicket();
        goldLadyEventTicket.setTicketNumber(51);
        goldLadyEventTicket.setSeatNumber("C1");

        GoldStagEventTicket goldStagEventTicket = new GoldStagEventTicket();
        goldStagEventTicket.setTicketNumber(81);
        goldStagEventTicket.setSeatNumber("E1");

        System.out.println("-----------Platinum Event Ticket Info--------------");
        platinumEventTicket.displayPlatinumEventInfo();
        System.out.println("-----------Gold Couple Event Ticket Info-----------");
        goldCoupleEventTicket.displayGoldEventInfo();
        System.out.println("-----------Gold Lady Event Ticket Info--------------");
        goldLadyEventTicket.displayGoldEventInfo();
        System.out.println("------------Gold Stag Event Ticket Info---------------");
        goldStagEventTicket.displayGoldEventInfo();

    }
}
