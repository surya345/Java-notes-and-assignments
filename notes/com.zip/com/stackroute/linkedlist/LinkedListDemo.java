package com.stackroute.linkedlist;

public class LinkedListDemo {

	public static void main(String[] args) {
	LinkedList list= new LinkedList();
	list.insert(10);
	list.insert(20);
	list.insert(45);
	
		
	}

}
