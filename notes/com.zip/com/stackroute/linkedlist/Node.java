package com.stackroute.linkedlist;

public class Node {

	//Student data;
	int data;
	Node next;
	
	
}
