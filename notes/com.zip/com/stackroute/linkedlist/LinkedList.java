package com.stackroute.linkedlist;

public class LinkedList {

	Node head;

	// create a node
	private Node createNode(int data) {
		/*
		 * data.setRoll(101); data.setName("roona"); data.setAddress("Delhi");
		 */

		Node node = new Node();

		node.data = data;
		node.next = null;
		return node;
	}

	// insert a node at last
	public void insert(int data) {

		// Node node = createNode(data);
		Node node = new Node();

		node.data = data;
		node.next = null;

		if (head == null) {
			head = node;
		}
		else {
			Node temp = head;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = node;
		}
	}

	// insert node at start position
	public void insertAtStart(int data) {
		Node node = createNode(data);

		node.next = head;
		head = node;
	}

	// insert node at given position
	public void insertAt(int index, int data) {

		Node node = createNode(data);

		if (index == 0) {
			insertAtStart(data);
		} 
		else {
			Node temp = head;

			for (int i = 0; i < index - 1; i++) {
				temp = temp.next;
			}
			node.next = temp.next;
			temp.next = node;
		}
	}

	// delete a particular node from the list
	public void delete(int index) {

		Node temp, temp1;
		temp = head;
		for (int i = 0; i < index - 1; i++) {
			temp = temp.next;
		}
		temp1 = temp.next;
		temp.next = temp1.next;
		temp1 = null;

	}

// print the list data
	public void show() {
		Node temp = head;
		while (temp.next != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
		System.out.println(temp.data);
	}

}
