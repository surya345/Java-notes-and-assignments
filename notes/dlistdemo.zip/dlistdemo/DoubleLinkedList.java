package dlistdemo;

public class DoubleLinkedList {
	
	Node head, tail;
	
	public Node createNode(int data) {
		
		Node node= new Node();
		node.data=data;
		node.next=null;
		node.prev= null;
		
		return node;
		
	}
	
	public void insert(int data) {
		
	Node node=	createNode(data);
		
		if(head==null) {
			head=node;
			tail=head;
		}else {
			Node temp=head;
			while(temp.next!=null) {
				temp= temp.next;
				
			}
			
			temp.next=node;
			node.prev=temp;
			tail=node;
			
		}
		
		
	}
	
	
	public void insertAt(int index, int data) {
		
	}
	
	public void show() {
		
		Node temp=head;
		while(temp!=null) {
			System.out.println(temp.data);
			temp=temp.next;
		}
	}

}
