package dlistdemo;

public class DlistDemo {

	public static void main(String[] args) {
		
		DoubleLinkedList list= new DoubleLinkedList();
		list.insert(20);
		list.insert(34);
		list.insert(45);
		list.show();
		
	}

}
