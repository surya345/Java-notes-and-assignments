package dsproject;

public class LinkedListDemo {

	public static void main(String[] args) {
		
		LinkedList list= new LinkedList();
		list.insert(new Student(101,"Roona", "Delhi"));
		list.insert(new Student(102,"Anuj", "Mumbai"));
		list.insert(new Student(104, "raj","Pune"));
		list.show();
	}

}
