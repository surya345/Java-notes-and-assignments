package dsproject;

public class LinkedList {

	Node head = null;

	/*
	 * public Node createNode(Student student) {
	 * 
	 * Node node= new Node(); node.studnet=student; node.next=null;
	 * 
	 * return node; }
	 */

	public void insert(Student student) {

		Node node = createNode(student);

		if (head == null) {
			head = node;
		}

		else {
			Node temp;
			temp = head;
			while (temp.next != null) {
				temp = temp.next;
			}
			temp.next = node;

		}

	}

	public void show() {

		Node temp;
		temp = head;
		while (temp != null) {
			System.out.println(temp.studnet);
			temp = temp.next;
		}

	}

	public Node createNode(Student student) {
		Node node = new Node();
		node.studnet = student;
		node.next = null;
		return node;
	}

	public void insertStart(Student student) {

	}

	public void insertAt(int index, Student studnet) {

	}

	public void delete(int index) {

	}

}
