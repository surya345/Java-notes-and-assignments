package dsproject;

public class Node {
	
	Student studnet;
	Node next;

}
