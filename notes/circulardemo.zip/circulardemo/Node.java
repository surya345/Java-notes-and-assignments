package circulardemo;

public class Node {

    Node next;
    int data;

    
}
