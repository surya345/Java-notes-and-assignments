package circulardemo;

public class CircularLinkedList {
    Node head;
    public Node createNode(int data){

    Node node= new Node();
    node.next=null;
    node.data=data;
    return node;

    }

    public void insert(int data){
       Node node= createNode(data);

        if(head==null){
            head=node;
             node.next=head;
        }
        else{
            Node temp=head;
            while(temp.next!=head){
                temp=temp.next;
            }
            temp.next=node;
            node.next=head;
        }

    }

    public void show(){

        Node temp= head;

        while(temp.next!=head){
            System.out.println(temp.data);
            temp=temp.next;
        }

        System.out.println(temp.data);



    }
    
}
