package circulardemo;

public class CurcularDemo {
    public static void main(String[] args) {

        CircularLinkedList list= new CircularLinkedList();
        list.insert(10);
        list.insert(20);
        list.show();

    }

   

    
}
